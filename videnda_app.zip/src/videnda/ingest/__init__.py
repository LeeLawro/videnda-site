"""Ingestion adapters: normalise heterogeneous inputs into canonical Assets."""
from __future__ import annotations

import os

from ..models import Inventory
from .csv_ingest import ingest_csv
from .nmap_ingest import ingest_nmap


def detect_format(path: str) -> str:
    lower = path.lower()
    if lower.endswith((".xml",)):
        return "nmap"
    if lower.endswith((".csv", ".xlsx", ".xls")):
        return "csv"
    # sniff: nmap xml starts with <?xml / <nmaprun
    try:
        with open(path, "r", errors="ignore") as fh:
            head = fh.read(200).lower()
        if "nmaprun" in head or ("<?xml" in head and "nmap" in head):
            return "nmap"
    except OSError:
        pass
    return "csv"


def ingest(path: str, fmt: str = "auto") -> Inventory:
    if fmt == "auto":
        fmt = detect_format(path)
    if fmt == "nmap":
        assets = ingest_nmap(path)
    elif fmt == "csv":
        assets = ingest_csv(path)
    else:
        raise ValueError(f"Unknown ingest format: {fmt}")
    return Inventory(assets=assets, source_files=[os.path.basename(path)])


__all__ = ["ingest", "ingest_csv", "ingest_nmap", "detect_format"]
