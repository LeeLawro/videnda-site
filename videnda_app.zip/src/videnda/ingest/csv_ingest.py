"""CSV / Excel ingestion.

Accepts a customer's existing asset spreadsheet with loosely-named columns and
maps them into canonical Assets. Column matching is fuzzy so operators do not
have to reformat their sheet first, a key part of the 'guided, no rework' UX.
"""
from __future__ import annotations

import csv
from typing import Iterable

from ..models import Asset
from ..taxonomy import Criticality, DeviceClass, classify_device

# canonical field -> possible header aliases (lowercased, non-alnum stripped)
_ALIASES: dict[str, tuple[str, ...]] = {
    "hostname": ("hostname", "host", "name", "devicename", "assetname", "tag"),
    "ip": ("ip", "ipaddress", "ipaddr", "address"),
    "mac": ("mac", "macaddress", "hwaddr"),
    "vendor": ("vendor", "manufacturer", "make", "oem"),
    "product": ("product", "producttype", "type", "devicetype", "description", "desc"),
    "model": ("model", "modelnumber", "partnumber", "catalog"),
    "firmware_version": ("firmware", "firmwareversion", "fwversion", "version", "revision"),
    "os": ("os", "operatingsystem", "osversion"),
    "site": ("site", "location", "facility", "plant"),
    "zone": ("zone", "cell", "area", "segment", "vlan"),
    "criticality": ("criticality", "critical", "importance", "priority"),
}


def _norm(s: str) -> str:
    return "".join(ch for ch in s.lower() if ch.isalnum())


def _build_header_map(headers: Iterable[str]) -> dict[str, str]:
    """Return {canonical_field: actual_header}."""
    norm_to_actual = {_norm(h): h for h in headers}
    out: dict[str, str] = {}
    for field, aliases in _ALIASES.items():
        for alias in aliases:
            if alias in norm_to_actual:
                out[field] = norm_to_actual[alias]
                break
    return out


def _criticality(value: str | None) -> Criticality:
    if not value:
        return Criticality.UNKNOWN
    v = value.strip().lower()
    if v in ("safety", "sil", "life"):
        return Criticality.SAFETY
    if v in ("high", "h", "critical", "3"):
        return Criticality.HIGH
    if v in ("medium", "med", "m", "2"):
        return Criticality.MEDIUM
    if v in ("low", "l", "1"):
        return Criticality.LOW
    return Criticality.UNKNOWN


def _rows_from_file(path: str) -> tuple[list[str], list[dict[str, str]]]:
    if path.lower().endswith((".xlsx", ".xls")):
        try:
            from openpyxl import load_workbook
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError("Reading .xlsx requires the 'excel' extra: pip install openpyxl") from exc
        wb = load_workbook(path, read_only=True, data_only=True)
        ws = wb.active
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            return [], []
        headers = [str(h) if h is not None else "" for h in rows[0]]
        dicts = [
            {headers[i]: ("" if c is None else str(c)) for i, c in enumerate(r) if i < len(headers)}
            for r in rows[1:]
        ]
        return headers, dicts
    with open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
        reader = csv.DictReader(fh)
        headers = reader.fieldnames or []
        return list(headers), list(reader)


def ingest_csv(path: str) -> list[Asset]:
    headers, rows = _rows_from_file(path)
    hmap = _build_header_map(headers)
    assets: list[Asset] = []
    for row in rows:
        def g(field: str) -> str | None:
            col = hmap.get(field)
            if not col:
                return None
            val = (row.get(col) or "").strip()
            return val or None

        vendor, product, model, os_ = g("vendor"), g("product"), g("model"), g("os")
        hostname = g("hostname")
        dc = classify_device(product, model, vendor, hostname, os_)
        assets.append(
            Asset(
                hostname=hostname,
                ip=g("ip"),
                mac=g("mac"),
                vendor=vendor,
                product=product,
                model=model,
                firmware_version=g("firmware_version"),
                os=os_,
                device_class=dc,
                criticality=_criticality(g("criticality")),
                site=g("site"),
                zone=g("zone"),
                source="csv",
                raw=dict(row),
            )
        )
    return assets
