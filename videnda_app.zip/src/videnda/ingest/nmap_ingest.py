"""Nmap XML ingestion.

Parses `nmap -oX` output (e.g. `nmap -sn`/`-sV` of an OT subnet run by the
customer) into canonical Assets: host addresses, OS guess, open ports and any
service product/version banners Nmap could read passively.
"""
from __future__ import annotations

try:
    import defusedxml.ElementTree as ET  # hardened: blocks entity expansion and external entities
except Exception:  # pragma: no cover - defusedxml expected in production
    import xml.etree.ElementTree as ET

from ..models import Asset
from ..taxonomy import classify_device


def ingest_nmap(path: str) -> list[Asset]:
    tree = ET.parse(path)
    root = tree.getroot()
    assets: list[Asset] = []

    for host in root.findall("host"):
        status = host.find("status")
        if status is not None and status.get("state") == "down":
            continue

        ip = mac = vendor = hostname = None
        for addr in host.findall("address"):
            atype = addr.get("addrtype")
            if atype == "ipv4":
                ip = addr.get("addr")
            elif atype == "mac":
                mac = addr.get("addr")
                vendor = addr.get("vendor") or vendor

        hn = host.find("hostnames/hostname")
        if hn is not None:
            hostname = hn.get("name")

        os_name = None
        osmatch = host.find("os/osmatch")
        if osmatch is not None:
            os_name = osmatch.get("name")

        open_ports: list[int] = []
        protocols: set[str] = set()
        product = model = version = None
        for port in host.findall("ports/port"):
            state = port.find("state")
            if state is None or state.get("state") != "open":
                continue
            try:
                open_ports.append(int(port.get("portid")))
            except (TypeError, ValueError):
                pass
            svc = port.find("service")
            if svc is not None:
                if svc.get("name"):
                    protocols.add(svc.get("name"))
                product = product or svc.get("product")
                version = version or svc.get("version")

        dc = classify_device(product, os_name, vendor, hostname)
        assets.append(
            Asset(
                hostname=hostname,
                ip=ip,
                mac=mac,
                vendor=vendor,
                product=product,
                model=model,
                firmware_version=version,
                os=os_name,
                device_class=dc,
                protocols=sorted(protocols),
                open_ports=sorted(open_ports),
                source="nmap",
                raw={"addresses": {"ip": ip, "mac": mac}},
            )
        )
    return assets
