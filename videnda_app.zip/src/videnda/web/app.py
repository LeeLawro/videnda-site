"""FastAPI front-end for the Videnda engine.

Sprint 1 "free diagnostic": a visitor uploads an existing asset spreadsheet or
an Nmap export, and gets a clean inventory, a risk snapshot and a prioritised
"fix these first" list, rendered in the browser. Files are processed in memory
and not stored.
"""
from __future__ import annotations

import html
import os
import tempfile

from fastapi import FastAPI, File, Form, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, Response

from ..ingest import ingest
from ..enrich import enrich
from ..risk import score_inventory
from ..report import build_summary
from ..models import Inventory

app = FastAPI(title="Videnda", description="Guided OT asset inventory and risk snapshot")

_SAMPLE = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "samples", "sample_assets.csv"))

# ---------------------------------------------------------------- styling
_CSS = """
:root{--navy:#1F3B5B;--navy2:#152B44;--blue:#2E75B6;--sky:#9CC4EF;--ink:#0e1a2b;
--mist:#c7d6ea;--line:#e2e8f2;--bg:#f5f8fc;--crit:#b23b3b;--high:#c8781d;--med:#c9a227;--low:#3f8f5b;}
*{box-sizing:border-box}
body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
color:var(--ink);background:var(--bg);line-height:1.55;}
header{background:radial-gradient(900px 500px at 75% -30%,#29527e,var(--navy));color:#eaf1fb;padding:22px 28px;}
header .bar{max-width:960px;margin:0 auto;display:flex;align-items:center;gap:14px;}
header h1{margin:0;font-size:20px;font-weight:700;letter-spacing:.02em;}
header span.sub{display:block;font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:var(--mist);font-weight:500;}
main{max-width:960px;margin:0 auto;padding:28px;}
.card{background:#fff;border:1px solid var(--line);border-radius:14px;padding:22px 24px;margin-bottom:20px;}
h2{font-size:18px;margin:0 0 14px;color:var(--navy);}
p.lede{font-size:16px;color:#3a4a60;margin:0 0 18px;}
.drop{border:2px dashed #bcccdf;border-radius:12px;padding:34px;text-align:center;background:#fbfdff;}
.drop input[type=file]{margin:12px 0;}
.btn{background:var(--navy);color:#fff;border:none;border-radius:10px;padding:12px 20px;font-size:15px;font-weight:600;cursor:pointer;text-decoration:none;display:inline-block;}
.btn.secondary{background:#fff;color:var(--navy);border:1px solid var(--navy);}
.muted{color:#65758c;font-size:13px;}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px;}
.stat{background:#f4f8fc;border:1px solid var(--line);border-radius:12px;padding:14px 16px;}
.stat .n{font-size:26px;font-weight:700;color:var(--navy);}
.stat .l{font-size:12px;color:#65758c;text-transform:uppercase;letter-spacing:.04em;}
table{width:100%;border-collapse:collapse;font-size:14px;}
th,td{text-align:left;padding:9px 10px;border-bottom:1px solid var(--line);vertical-align:top;}
th{background:var(--navy);color:#fff;font-weight:600;}
tr:nth-child(even) td{background:#f8fbfe;}
.pill{display:inline-block;padding:2px 9px;border-radius:20px;font-size:12px;font-weight:600;color:#fff;}
.b-Critical{background:var(--crit);}.b-High{background:var(--high);}.b-Medium{background:var(--med);}.b-Low{background:var(--low);}.b-None{background:#9aa7b8;}
ol.fix{margin:0;padding-left:20px;} ol.fix li{margin-bottom:8px;}
.note{font-size:12px;color:#65758c;border-top:1px solid var(--line);margin-top:22px;padding-top:14px;}
a{color:var(--blue);}
.err{background:#fdecec;border:1px solid #f3b8b8;color:#8a2a2a;border-radius:10px;padding:14px 16px;}
"""

_LOGO = (
    '<svg width="42" height="42" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'
    '<path d="M226 352 L286 352 L256 430 Z" fill="#9CC4EF"/>'
    '<line x1="150" y1="132" x2="256" y2="322" stroke="#6FA8DA" stroke-width="76"/>'
    '<line x1="362" y1="132" x2="256" y2="322" stroke="#9CC4EF" stroke-width="76"/>'
    '<circle cx="256" cy="322" r="63" fill="none" stroke="#DCEBFB" stroke-width="5"/>'
    '<circle cx="256" cy="322" r="58" fill="#2E75B6"/>'
    '<circle cx="256" cy="322" r="33" fill="#12243A"/>'
    '<circle cx="238" cy="305" r="11" fill="#DCEBFB"/></svg>'
)


def _page(title: str, body: str) -> str:
    return (
        "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"/>"
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>"
        f"<title>{html.escape(title)}</title><style>{_CSS}</style></head><body>"
        f"<header><div class=\"bar\">{_LOGO}<div><h1>Videnda</h1>"
        "<span class=\"sub\">Operational Technology</span></div></div></header>"
        f"<main>{body}</main></body></html>"
    )


def _upload_body(message: str = "") -> str:
    err = f"<div class=\"card err\">{html.escape(message)}</div>" if message else ""
    return (
        f"{err}"
        "<div class=\"card\">"
        "<h2>See what's on your OT network</h2>"
        "<p class=\"lede\">Upload an existing asset spreadsheet (CSV or Excel) or an Nmap scan (XML). "
        "Videnda builds a clean, government-taxonomy-aligned inventory, checks it against public "
        "vulnerability intelligence, and shows you what to fix first.</p>"
        "<form action=\"/scan\" method=\"post\" enctype=\"multipart/form-data\">"
        "<div class=\"drop\">"
        "<div><strong>Choose a file to analyse</strong></div>"
        "<input type=\"file\" name=\"file\" accept=\".csv,.xlsx,.xls,.xml\" required/>"
        "<div class=\"muted\">CSV, Excel (.xlsx) or Nmap XML. Processed in memory, not stored.</div>"
        "</div><div style=\"margin-top:16px;display:flex;gap:12px;flex-wrap:wrap;\">"
        "<button class=\"btn\" type=\"submit\">Run the snapshot</button>"
        "<a class=\"btn secondary\" href=\"/scan-sample\">Try it with sample data</a>"
        "</div></form></div>"
        "<div class=\"card\"><h2>What you get</h2>"
        "<p class=\"lede\" style=\"margin:0\">A device inventory, a count of known-exploited vulnerabilities, "
        "end-of-life systems, likely default credentials and internet-exposed devices, plus a ranked "
        "\"fix these first\" list. No security expertise required.</p></div>"
    )


def _results_body(inv: Inventory) -> str:
    s = build_summary(inv)
    f = s["findings"]
    stats = (
        "<div class=\"grid\">"
        f"<div class=\"stat\"><div class=\"n\">{s['total_assets']}</div><div class=\"l\">Assets found</div></div>"
        f"<div class=\"stat\"><div class=\"n\">{f['known_exploited_vulns']}</div><div class=\"l\">Known-exploited vulns</div></div>"
        f"<div class=\"stat\"><div class=\"n\">{f['end_of_life']}</div><div class=\"l\">End of life</div></div>"
        f"<div class=\"stat\"><div class=\"n\">{f['likely_default_creds']}</div><div class=\"l\">Likely default creds</div></div>"
        f"<div class=\"stat\"><div class=\"n\">{f['internet_exposed']}</div><div class=\"l\">Internet exposed</div></div>"
        "</div>"
    )

    fixes = "".join(
        f"<li><span class=\"pill b-{html.escape(t['risk_band'])}\">{html.escape(t['risk_band'])} {t['risk_score']}</span> "
        f"<strong>{html.escape(str(t['label']))}</strong> ({html.escape(t['device_class'])}) "
        f": {html.escape(str(t['top_finding'] or ''))}</li>"
        for t in s["top_risks"]
    ) or "<li>No risks detected in this file.</li>"

    rows = ""
    ranked = sorted(inv.assets, key=lambda a: a.risk_score, reverse=True)
    for a in ranked:
        label = a.hostname or a.ip or a.product or a.asset_id
        top = a.findings[0].title if a.findings else ""
        rows += (
            "<tr>"
            f"<td>{html.escape(str(label))}</td>"
            f"<td>{html.escape(a.device_class.value)}</td>"
            f"<td>{html.escape(a.purdue_level.value)}</td>"
            f"<td><span class=\"pill b-{html.escape(a.risk_band)}\">{html.escape(a.risk_band)} {a.risk_score}</span></td>"
            f"<td>{html.escape(str(top))}</td>"
            "</tr>"
        )

    return (
        "<div class=\"card\"><h2>Asset & risk snapshot</h2>"
        f"<p class=\"muted\">Source: {html.escape(', '.join(s['source_files']) or 'upload')} "
        f"&middot; {s['assets_with_findings']} of {s['total_assets']} assets have findings.</p>"
        f"{stats}</div>"
        "<div class=\"card\"><h2>Fix these first</h2>"
        f"<ol class=\"fix\">{fixes}</ol></div>"
        "<div class=\"card\"><h2>Full inventory</h2>"
        "<table><thead><tr><th>Asset</th><th>Class</th><th>Purdue level</th><th>Risk</th><th>Top finding</th></tr></thead>"
        f"<tbody>{rows}</tbody></table>"
        "<p class=\"note\">Findings are automated, from public sources (CISA KEV, ICS advisories, "
        "end-of-life lists). \"Likely default credentials\" are unverified and should be confirmed on the "
        "device. This is not a substitute for review by a competent person. Your file was processed in "
        "memory and has not been stored.</p></div>"
        "<a class=\"btn\" href=\"/\">Scan another file</a>"
    )


def _run(path: str, fmt: str = "auto") -> Inventory:
    inv = ingest(path, fmt=fmt)
    enrich(inv)
    score_inventory(inv)
    return inv


@app.get("/", response_class=HTMLResponse)
def home() -> HTMLResponse:
    return HTMLResponse(_page("Videnda | OT asset snapshot", _upload_body()))


@app.get("/health", response_class=JSONResponse)
def health() -> JSONResponse:
    return JSONResponse({"status": "ok"})


@app.get("/scan-sample", response_class=HTMLResponse)
def scan_sample() -> HTMLResponse:
    inv = _run(_SAMPLE, fmt="csv")
    return HTMLResponse(_page("Videnda | Snapshot", _results_body(inv)))


@app.post("/scan", response_class=HTMLResponse)
async def scan(file: UploadFile = File(...), format: str = Form("auto")) -> Response:
    data = await file.read()
    if not data:
        return HTMLResponse(_page("Videnda", _upload_body("That file was empty. Please choose a file with asset data.")), status_code=400)
    suffix = os.path.splitext(file.filename or "")[1] or ".csv"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        tmp.write(data)
        tmp.close()
        inv = _run(tmp.name, fmt=format)
    except Exception as exc:  # noqa: BLE001 - surface a friendly message
        return HTMLResponse(_page("Videnda", _upload_body(f"Could not read that file: {exc}")), status_code=400)
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass
    return HTMLResponse(_page("Videnda | Snapshot", _results_body(inv)))


@app.post("/api/scan", response_class=JSONResponse)
async def api_scan(file: UploadFile = File(...), format: str = Form("auto")) -> JSONResponse:
    data = await file.read()
    if not data:
        return JSONResponse({"error": "empty file"}, status_code=400)
    suffix = os.path.splitext(file.filename or "")[1] or ".csv"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        tmp.write(data)
        tmp.close()
        inv = _run(tmp.name, fmt=format)
    except Exception as exc:  # noqa: BLE001
        return JSONResponse({"error": str(exc)}, status_code=400)
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass
    return JSONResponse({
        "summary": build_summary(inv),
        "assets": [a.model_dump(mode="json") for a in inv.assets],
    })
