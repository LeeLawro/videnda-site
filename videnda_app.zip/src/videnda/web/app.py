"""FastAPI front-end for the Videnda engine.

Sprint 1 "free diagnostic": a visitor uploads an existing asset spreadsheet or
an Nmap export, and gets a clean inventory, a risk snapshot and a prioritised
"fix these first" list, rendered in the browser. Files are processed in memory
and not stored.
"""
from __future__ import annotations

import html
import json
import os
import tempfile

from fastapi import FastAPI, File, Form, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, Response

from ..ingest import ingest
from ..enrich import enrich
from ..risk import score_inventory
from ..report import build_summary
from ..models import Inventory

app = FastAPI(title="Videnda", description="Guided OT asset inventory and risk snapshot")

_SAMPLE = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "samples", "sample_assets.csv"))

# ---------------------------------------------------------------- styling
_CSS = """
:root{--navy:#1F3B5B;--navy2:#152B44;--blue:#2E75B6;--sky:#9CC4EF;--ink:#0e1a2b;
--mist:#c7d6ea;--line:#e2e8f2;--bg:#f5f8fc;--crit:#b23b3b;--high:#c8781d;--med:#c9a227;--low:#3f8f5b;}
*{box-sizing:border-box}
body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
color:var(--ink);background:var(--bg);line-height:1.55;}
header{background:radial-gradient(900px 500px at 75% -30%,#29527e,var(--navy));color:#eaf1fb;padding:22px 28px;}
header .bar{max-width:960px;margin:0 auto;display:flex;align-items:center;gap:14px;}
header h1{margin:0;font-size:20px;font-weight:700;letter-spacing:.02em;}
header span.sub{display:block;font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:var(--mist);font-weight:500;}
main{max-width:960px;margin:0 auto;padding:28px;}
.card{background:#fff;border:1px solid var(--line);border-radius:14px;padding:22px 24px;margin-bottom:20px;}
h2{font-size:18px;margin:0 0 14px;color:var(--navy);}
p.lede{font-size:16px;color:#3a4a60;margin:0 0 18px;}
.drop{border:2px dashed #bcccdf;border-radius:12px;padding:34px;text-align:center;background:#fbfdff;}
.drop input[type=file]{margin:12px 0;}
.btn{background:var(--navy);color:#fff;border:none;border-radius:10px;padding:12px 20px;font-size:15px;font-weight:600;cursor:pointer;text-decoration:none;display:inline-block;}
.btn.secondary{background:#fff;color:var(--navy);border:1px solid var(--navy);}
.muted{color:#65758c;font-size:13px;}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px;}
.stat{background:#f4f8fc;border:1px solid var(--line);border-radius:12px;padding:14px 16px;}
.stat .n{font-size:26px;font-weight:700;color:var(--navy);}
.stat .l{font-size:12px;color:#65758c;text-transform:uppercase;letter-spacing:.04em;}
table{width:100%;border-collapse:collapse;font-size:14px;}
th,td{text-align:left;padding:9px 10px;border-bottom:1px solid var(--line);vertical-align:top;}
th{background:var(--navy);color:#fff;font-weight:600;}
tr:nth-child(even) td{background:#f8fbfe;}
.pill{display:inline-block;padding:2px 9px;border-radius:20px;font-size:12px;font-weight:600;color:#fff;}
.b-Critical{background:var(--crit);}.b-High{background:var(--high);}.b-Medium{background:var(--med);}.b-Low{background:var(--low);}.b-None{background:#9aa7b8;}
ol.fix{margin:0;padding-left:20px;} ol.fix li{margin-bottom:8px;}
.note{font-size:12px;color:#65758c;border-top:1px solid var(--line);margin-top:22px;padding-top:14px;}
a{color:var(--blue);}
.err{background:#fdecec;border:1px solid #f3b8b8;color:#8a2a2a;border-radius:10px;padding:14px 16px;}
details.help{border:1px solid var(--line);border-radius:12px;margin-top:12px;background:#fbfdff;overflow:hidden;}
details.help>summary{list-style:none;cursor:pointer;padding:14px 16px;font-weight:600;color:var(--navy);display:flex;align-items:center;gap:10px;}
details.help>summary::-webkit-details-marker{display:none;}
details.help>summary .ic{width:26px;height:26px;flex:none;border-radius:7px;background:#e8f0fb;color:var(--blue);display:flex;align-items:center;justify-content:center;font-size:14px;}
details.help>summary .cx{margin-left:auto;color:var(--blue);font-size:13px;font-weight:600;}
details.help>summary .cx::after{content:"View";}
details.help[open]>summary .cx::after{content:"Close";}
details.help[open]>summary{border-bottom:1px solid var(--line);}
.help .bd{padding:6px 18px 18px;font-size:14px;color:#3a4a60;}
.help .bd ol{margin:8px 0;padding-left:20px;} .help .bd li{margin-bottom:7px;}
.help .bd .cols{display:flex;flex-wrap:wrap;gap:6px;margin:10px 0;}
.help .bd .cols code{background:#eef3fa;border:1px solid #dce6f3;border-radius:6px;padding:3px 8px;font-size:12px;color:#2b4a6f;}
pre.cmd{background:#12243a;color:#dcebfb;border-radius:9px;padding:12px 14px;font-size:13px;overflow-x:auto;margin:10px 0;}
pre.cmd .cmt{color:#7f9dc0;}
.riskbar{display:flex;height:14px;border-radius:8px;overflow:hidden;margin:4px 0 10px;border:1px solid var(--line);}
.riskbar span{display:block;}
.rk-legend{display:flex;flex-wrap:wrap;gap:14px;font-size:12px;color:#65758c;}
.rk-legend .k{display:inline-flex;align-items:center;gap:6px;}
.rk-legend .sw{width:11px;height:11px;border-radius:3px;display:inline-block;}
.inline-link{font-weight:600;}
"""

_LOGO = (
    '<svg width="42" height="42" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'
    '<path d="M226 352 L286 352 L256 430 Z" fill="#9CC4EF"/>'
    '<line x1="150" y1="132" x2="256" y2="322" stroke="#6FA8DA" stroke-width="76"/>'
    '<line x1="362" y1="132" x2="256" y2="322" stroke="#9CC4EF" stroke-width="76"/>'
    '<circle cx="256" cy="322" r="63" fill="none" stroke="#DCEBFB" stroke-width="5"/>'
    '<circle cx="256" cy="322" r="58" fill="#2E75B6"/>'
    '<circle cx="256" cy="322" r="33" fill="#12243A"/>'
    '<circle cx="238" cy="305" r="11" fill="#DCEBFB"/></svg>'
)


_CLARITY = (
    "<script type=\"text/javascript\">(function(c,l,a,r,i,t,y){"
    "c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};"
    "t=l.createElement(r);t.async=1;t.src=\"https://www.clarity.ms/tag/\"+i;"
    "y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);"
    "})(window, document, \"clarity\", \"script\", \"xkumqj2brj\");</script>"
)


def _page(title: str, body: str) -> str:
    return (
        "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"/>"
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>"
        f"<title>{html.escape(title)}</title><style>{_CSS}</style>{_CLARITY}</head><body>"
        f"<header><div class=\"bar\">{_LOGO}<div><h1>Videnda</h1>"
        "<span class=\"sub\">Operational Technology</span></div></div></header>"
        f"<main>{body}</main></body></html>"
    )


def _upload_body(message: str = "") -> str:
    err = f"<div class=\"card err\">{html.escape(message)}</div>" if message else ""
    return (
        f"{err}"
        "<div class=\"card\">"
        "<h2>See what's on your OT network</h2>"
        "<p class=\"lede\">Upload an existing asset spreadsheet (CSV or Excel) or an Nmap scan (XML). "
        "Videnda builds a clean, government-taxonomy-aligned inventory, checks it against public "
        "vulnerability intelligence, and shows you what to fix first.</p>"
        "<form action=\"/scan\" method=\"post\" enctype=\"multipart/form-data\">"
        "<div class=\"drop\">"
        "<div><strong>Choose a file to analyse</strong></div>"
        "<input type=\"file\" name=\"file\" accept=\".csv,.xlsx,.xls,.xml\" required/>"
        "<div class=\"muted\">CSV, Excel (.xlsx) or Nmap XML. Processed in memory, not stored.</div>"
        "</div><div style=\"margin-top:16px;display:flex;gap:12px;flex-wrap:wrap;\">"
        "<button class=\"btn\" type=\"submit\">Run the snapshot</button>"
        "<a class=\"btn secondary\" href=\"/scan-sample\">Try it with sample data</a>"
        "</div>"
        "<p class=\"muted\" style=\"margin-top:12px\">Not sure how to make a file? Use the guides below, "
        "or just try the sample data first.</p>"
        "<details class=\"help\"><summary><span class=\"ic\">1</span>Build an asset list in Excel or Sheets"
        "<span class=\"cx\"></span></summary><div class=\"bd\">"
        "<ol><li>Open a blank spreadsheet and put these headings in the first row:</li></ol>"
        "<div class=\"cols\"><code>Asset Name</code><code>IP Address</code><code>Manufacturer</code>"
        "<code>Device Type</code><code>Model</code><code>Firmware</code><code>Operating System</code>"
        "<code>Location</code><code>Criticality</code></div>"
        "<ol start=\"2\"><li>Add one row per device. You don't need every column: even just "
        "<strong>Asset Name, IP Address and Manufacturer</strong> gives a useful result.</li>"
        "<li>Save or export as <strong>CSV</strong> (File &rarr; Save As &rarr; CSV), then upload it above.</li></ol>"
        "<p><a class=\"inline-link\" href=\"/template.csv\">Download a ready-made CSV template</a> "
        "with the headings and example rows.</p>"
        "</div></details>"
        "<details class=\"help\"><summary><span class=\"ic\">2</span>Produce an Nmap scan (XML)"
        "<span class=\"cx\"></span></summary><div class=\"bd\">"
        "<p>If you have Nmap installed and permission to scan your network, run a light discovery scan "
        "and save it as XML:</p>"
        "<pre class=\"cmd\"><span class=\"cmt\"># replace 10.20.1.0/24 with your OT subnet</span>\n"
        "nmap -sn -oX assets.xml 10.20.1.0/24</pre>"
        "<p>For more detail (open ports and service guesses), a slower option:</p>"
        "<pre class=\"cmd\">nmap -sV -O -oX assets.xml 10.20.1.0/24</pre>"
        "<p class=\"muted\">Only scan networks you are authorised to. On sensitive OT, prefer the light "
        "<code>-sn</code> scan, or export an asset list from your switch or CMDB instead.</p>"
        "<p>Then upload the <strong>assets.xml</strong> file above.</p>"
        "</div></details>"
        "<details class=\"help\"><summary><span class=\"ic\">&#9658;</span>Watch a 30-second walkthrough"
        "<span class=\"cx\"></span></summary><div class=\"bd\">"
        "<img src=\"/tutorial.gif\" alt=\"Walkthrough: build a CSV or run an Nmap scan, then upload\" "
        "style=\"width:100%;border-radius:10px;border:1px solid var(--line)\"/>"
        "</div></details>"
        "</form></div>"
        "<div class=\"card\"><h2>What you get</h2>"
        "<p class=\"lede\" style=\"margin:0\">A device inventory, a count of known-exploited vulnerabilities, "
        "end-of-life systems, likely default credentials and internet-exposed devices, plus a ranked "
        "\"fix these first\" list. No security expertise required.</p></div>"
    )


def _results_body(inv: Inventory) -> str:
    s = build_summary(inv)
    f = s["findings"]
    stats = (
        "<div class=\"grid\">"
        f"<div class=\"stat\"><div class=\"n\">{s['total_assets']}</div><div class=\"l\">Assets found</div></div>"
        f"<div class=\"stat\"><div class=\"n\">{f['known_exploited_vulns']}</div><div class=\"l\">Known-exploited vulns</div></div>"
        f"<div class=\"stat\"><div class=\"n\">{f['end_of_life']}</div><div class=\"l\">End of life</div></div>"
        f"<div class=\"stat\"><div class=\"n\">{f['likely_default_creds']}</div><div class=\"l\">Likely default creds</div></div>"
        f"<div class=\"stat\"><div class=\"n\">{f['internet_exposed']}</div><div class=\"l\">Internet exposed</div></div>"
        "</div>"
    )

    bands = ["Critical", "High", "Medium", "Low", "None"]
    band_colors = {"Critical": "var(--crit)", "High": "var(--high)", "Medium": "var(--med)",
                   "Low": "var(--low)", "None": "#9aa7b8"}
    counts = {b: 0 for b in bands}
    for a in inv.assets:
        counts[a.risk_band if a.risk_band in counts else "None"] += 1
    total = max(sum(counts.values()), 1)
    segments = "".join(
        f"<span style=\"width:{counts[b] / total * 100:.1f}%;background:{band_colors[b]};\" "
        f"title=\"{b}: {counts[b]}\"></span>"
        for b in bands if counts[b]
    )
    legend = "".join(
        f"<span class=\"k\"><span class=\"sw\" style=\"background:{band_colors[b]};\"></span>"
        f"{b} {counts[b]}</span>"
        for b in bands if counts[b]
    )
    riskbar = (
        f"<div class=\"riskbar\">{segments}</div><div class=\"rk-legend\">{legend}</div>"
        if segments else ""
    )

    fixes = "".join(
        f"<li><span class=\"pill b-{html.escape(t['risk_band'])}\">{html.escape(t['risk_band'])} {t['risk_score']}</span> "
        f"<strong>{html.escape(str(t['label']))}</strong> ({html.escape(t['device_class'])}) "
        f": {html.escape(str(t['top_finding'] or ''))}</li>"
        for t in s["top_risks"]
    ) or "<li>No risks detected in this file.</li>"

    rows = ""
    ranked = sorted(inv.assets, key=lambda a: a.risk_score, reverse=True)
    for a in ranked:
        label = a.hostname or a.ip or a.product or a.asset_id
        top = a.findings[0].title if a.findings else ""
        rows += (
            "<tr>"
            f"<td>{html.escape(str(label))}</td>"
            f"<td>{html.escape(a.device_class.value)}</td>"
            f"<td>{html.escape(a.purdue_level.value)}</td>"
            f"<td><span class=\"pill b-{html.escape(a.risk_band)}\">{html.escape(a.risk_band)} {a.risk_score}</span></td>"
            f"<td>{html.escape(str(top))}</td>"
            "</tr>"
        )

    return (
        "<div class=\"card\"><h2>Asset & risk snapshot</h2>"
        f"<p class=\"muted\">Source: {html.escape(', '.join(s['source_files']) or 'upload')} "
        f"&middot; {s['assets_with_findings']} of {s['total_assets']} assets have findings.</p>"
        f"{riskbar}{stats}</div>"
        "<div class=\"card\"><h2>Fix these first</h2>"
        f"<ol class=\"fix\">{fixes}</ol></div>"
        "<div class=\"card\"><h2>Full inventory</h2>"
        "<table><thead><tr><th>Asset</th><th>Class</th><th>Purdue level</th><th>Risk</th><th>Top finding</th></tr></thead>"
        f"<tbody>{rows}</tbody></table>"
        "<p class=\"note\">Findings are automated, from public sources (CISA KEV, ICS advisories, "
        "end-of-life lists). \"Likely default credentials\" are unverified and should be confirmed on the "
        "device. This is not a substitute for review by a competent person. Your file was processed in "
        "memory and has not been stored.</p></div>"
        "<div class=\"card\" id=\"fb\"><h2>How was this?</h2>"
        "<p class=\"muted\" style=\"margin-top:-6px\">A few seconds of feedback helps us build the right thing.</p>"
        "<div id=\"fbform\">"
        "<div style=\"display:flex;gap:10px;margin-bottom:12px;flex-wrap:wrap\">"
        "<button type=\"button\" class=\"btn secondary\" onclick=\"fbRate('useful',this)\">&#128077; Useful</button>"
        "<button type=\"button\" class=\"btn secondary\" onclick=\"fbRate('not-useful',this)\">&#128078; Not quite</button>"
        "</div>"
        "<textarea id=\"fbc\" rows=\"3\" placeholder=\"Anything we could improve? (optional)\" style=\"width:100%;border:1px solid var(--line);border-radius:10px;padding:10px;font:inherit\"></textarea>"
        "<input id=\"fbe\" type=\"email\" placeholder=\"Email, if you would like a reply (optional)\" style=\"width:100%;border:1px solid var(--line);border-radius:10px;padding:10px;margin-top:8px;font:inherit\"/>"
        "<div style=\"margin-top:12px\"><button type=\"button\" class=\"btn\" onclick=\"fbSend()\">Send feedback</button></div>"
        "</div>"
        "<div id=\"fbthanks\" style=\"display:none;font-size:15px;color:var(--low)\">Thank you, that is really helpful.</div>"
        "</div>"
        "<script>var fbR='';function fbRate(v,b){fbR=v;var bs=b.parentNode.querySelectorAll('button');for(var i=0;i<bs.length;i++){bs[i].style.background='';bs[i].style.color='var(--navy)';}b.style.background='var(--navy)';b.style.color='#fff';}"
        "function fbSend(){var d=new FormData();d.append('rating',fbR);d.append('comment',document.getElementById('fbc').value);d.append('email',document.getElementById('fbe').value);fetch('/feedback',{method:'POST',body:d});document.getElementById('fbform').style.display='none';document.getElementById('fbthanks').style.display='block';}</script>"
        "<a class=\"btn\" href=\"/\">Scan another file</a>"
    )


def _run(path: str, fmt: str = "auto") -> Inventory:
    inv = ingest(path, fmt=fmt)
    enrich(inv)
    score_inventory(inv)
    return inv


@app.get("/", response_class=HTMLResponse)
def home() -> HTMLResponse:
    return HTMLResponse(_page("Videnda | OT asset snapshot", _upload_body()))


@app.get("/health", response_class=JSONResponse)
def health() -> JSONResponse:
    return JSONResponse({"status": "ok"})


@app.get("/scan-sample", response_class=HTMLResponse)
def scan_sample() -> HTMLResponse:
    inv = _run(_SAMPLE, fmt="csv")
    return HTMLResponse(_page("Videnda | Snapshot", _results_body(inv)))


_TEMPLATE_CSV = (
    "Asset Name,IP Address,Manufacturer,Device Type,Model,Firmware,Operating System,Location,Criticality\n"
    "LINE1-PLC-01,10.20.1.11,Siemens,PLC,SIMATIC S7-1500,2.8,,Plant A,High\n"
    "HIST-SRV-01,10.20.2.10,Microsoft,Historian Server,PI Server,,Windows Server 2008,Plant A,High\n"
    "BMS-JACE-1,10.20.3.30,Tridium,BMS Controller,JACE 8000,,,Plant A,Medium\n"
    ",,,,,,,,\n"
    ",,,,,,,,\n"
)


@app.get("/template.csv")
def template_csv() -> Response:
    return Response(
        content=_TEMPLATE_CSV,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=videnda-asset-template.csv"},
    )


_TUTORIAL_GIF = os.path.join(os.path.dirname(__file__), "tutorial.gif")


@app.get("/tutorial.gif")
def tutorial_gif() -> Response:
    with open(_TUTORIAL_GIF, "rb") as fh:
        return Response(content=fh.read(), media_type="image/gif")


@app.post("/feedback", response_class=JSONResponse)
async def feedback(rating: str = Form(""), comment: str = Form(""), email: str = Form("")) -> JSONResponse:
    entry = {"rating": rating[:20], "comment": comment[:2000], "email": email[:200]}
    print("VIDENDA_FEEDBACK " + json.dumps(entry), flush=True)
    return JSONResponse({"ok": True})


@app.post("/scan", response_class=HTMLResponse)
async def scan(file: UploadFile = File(...), format: str = Form("auto")) -> Response:
    data = await file.read()
    if not data:
        return HTMLResponse(_page("Videnda", _upload_body("That file was empty. Please choose a file with asset data.")), status_code=400)
    suffix = os.path.splitext(file.filename or "")[1] or ".csv"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        tmp.write(data)
        tmp.close()
        inv = _run(tmp.name, fmt=format)
    except Exception as exc:  # noqa: BLE001 - surface a friendly message
        return HTMLResponse(_page("Videnda", _upload_body(f"Could not read that file: {exc}")), status_code=400)
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass
    return HTMLResponse(_page("Videnda | Snapshot", _results_body(inv)))


@app.post("/api/scan", response_class=JSONResponse)
async def api_scan(file: UploadFile = File(...), format: str = Form("auto")) -> JSONResponse:
    data = await file.read()
    if not data:
        return JSONResponse({"error": "empty file"}, status_code=400)
    suffix = os.path.splitext(file.filename or "")[1] or ".csv"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        tmp.write(data)
        tmp.close()
        inv = _run(tmp.name, fmt=format)
    except Exception as exc:  # noqa: BLE001
        return JSONResponse({"error": str(exc)}, status_code=400)
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass
    return JSONResponse({
        "summary": build_summary(inv),
        "assets": [a.model_dump(mode="json") for a in inv.assets],
    })
