"""Videnda web app (Sprint 1): the free diagnostic, upload a file and get a snapshot."""
