"""CISA-aligned OT taxonomy.

Mirrors the structure in CISA/NSA/FBI "Foundations for OT Cybersecurity:
Asset Inventory Guidance for Owners and Operators" (Aug 2025): every asset is
classified by a device class and a Purdue reference-architecture level so the
inventory can be reasoned about consistently and mapped to compliance frameworks.
"""
from __future__ import annotations
from enum import Enum


class PurdueLevel(str, Enum):
    L0_PROCESS = "L0_Process"              # sensors / actuators
    L1_CONTROL = "L1_BasicControl"         # PLCs / RTUs / controllers
    L2_SUPERVISORY = "L2_Supervisory"      # HMI / SCADA / DCS operator stations
    L3_OPERATIONS = "L3_Operations"        # historians, engineering workstations
    L3_5_DMZ = "L3.5_IDMZ"                 # industrial DMZ
    L4_ENTERPRISE = "L4_Enterprise"        # business IT
    UNKNOWN = "Unknown"


class DeviceClass(str, Enum):
    PLC = "PLC"
    RTU = "RTU"
    DCS_CONTROLLER = "DCS_Controller"
    HMI = "HMI"
    SCADA_SERVER = "SCADA_Server"
    ENGINEERING_WORKSTATION = "Engineering_Workstation"
    HISTORIAN = "Historian"
    SENSOR = "Sensor"
    ACTUATOR = "Actuator"
    DRIVE_VFD = "Drive_VFD"
    PROTECTION_RELAY = "Protection_Relay"
    BMS_CONTROLLER = "BMS_Controller"
    IP_CAMERA = "IP_Camera"
    NETWORK_SWITCH = "Network_Switch"
    ROUTER = "Router"
    FIREWALL = "Firewall"
    IOT_GATEWAY = "IoT_Gateway"
    SERVER = "Server"
    WORKSTATION = "Workstation"
    PRINTER = "Printer"
    UNKNOWN = "Unknown"


class Criticality(str, Enum):
    SAFETY = "Safety"     # loss could cause a safety / life event
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"
    UNKNOWN = "Unknown"


# Rough default Purdue level per device class, used when a source does not
# specify one. Deliberately conservative; a human can override.
DEFAULT_PURDUE: dict[DeviceClass, PurdueLevel] = {
    DeviceClass.SENSOR: PurdueLevel.L0_PROCESS,
    DeviceClass.ACTUATOR: PurdueLevel.L0_PROCESS,
    DeviceClass.PLC: PurdueLevel.L1_CONTROL,
    DeviceClass.RTU: PurdueLevel.L1_CONTROL,
    DeviceClass.DRIVE_VFD: PurdueLevel.L1_CONTROL,
    DeviceClass.PROTECTION_RELAY: PurdueLevel.L1_CONTROL,
    DeviceClass.DCS_CONTROLLER: PurdueLevel.L1_CONTROL,
    DeviceClass.BMS_CONTROLLER: PurdueLevel.L1_CONTROL,
    DeviceClass.HMI: PurdueLevel.L2_SUPERVISORY,
    DeviceClass.SCADA_SERVER: PurdueLevel.L2_SUPERVISORY,
    DeviceClass.HISTORIAN: PurdueLevel.L3_OPERATIONS,
    DeviceClass.ENGINEERING_WORKSTATION: PurdueLevel.L3_OPERATIONS,
    DeviceClass.IP_CAMERA: PurdueLevel.L2_SUPERVISORY,
    DeviceClass.IOT_GATEWAY: PurdueLevel.L3_5_DMZ,
    DeviceClass.NETWORK_SWITCH: PurdueLevel.L2_SUPERVISORY,
    DeviceClass.ROUTER: PurdueLevel.L3_5_DMZ,
    DeviceClass.FIREWALL: PurdueLevel.L3_5_DMZ,
    DeviceClass.SERVER: PurdueLevel.L4_ENTERPRISE,
    DeviceClass.WORKSTATION: PurdueLevel.L4_ENTERPRISE,
    DeviceClass.PRINTER: PurdueLevel.L4_ENTERPRISE,
    DeviceClass.UNKNOWN: PurdueLevel.UNKNOWN,
}

# Lower Purdue level == closer to the physical process == higher blast radius.
PURDUE_RISK_WEIGHT: dict[PurdueLevel, float] = {
    PurdueLevel.L0_PROCESS: 1.30,
    PurdueLevel.L1_CONTROL: 1.30,
    PurdueLevel.L2_SUPERVISORY: 1.15,
    PurdueLevel.L3_OPERATIONS: 1.05,
    PurdueLevel.L3_5_DMZ: 1.00,
    PurdueLevel.L4_ENTERPRISE: 0.90,
    PurdueLevel.UNKNOWN: 1.00,
}

CRITICALITY_RISK_WEIGHT: dict[Criticality, float] = {
    Criticality.SAFETY: 1.35,
    Criticality.HIGH: 1.20,
    Criticality.MEDIUM: 1.00,
    Criticality.LOW: 0.85,
    Criticality.UNKNOWN: 1.00,
}

# Keyword hints for classifying free-text device descriptions from CSV / Nmap.
_CLASS_KEYWORDS: list[tuple[DeviceClass, tuple[str, ...]]] = [
    (DeviceClass.PLC, ("plc", "s7-", "simatic", "controllogix", "compactlogix", "modicon", "logix")),
    (DeviceClass.RTU, ("rtu", "remote terminal")),
    (DeviceClass.HMI, ("hmi", "panelview", "operator panel", "touch panel")),
    (DeviceClass.SCADA_SERVER, ("scada", "wincc", "ignition", "clearscada", "ifix")),
    (DeviceClass.HISTORIAN, ("historian", "pi server", "osisoft", "aveva historian")),
    (DeviceClass.ENGINEERING_WORKSTATION, ("engineering workstation", "ews", "tia portal", "studio 5000")),
    (DeviceClass.PROTECTION_RELAY, ("relay", "siprotec", "sel-", "protection")),
    (DeviceClass.DRIVE_VFD, ("vfd", "variable frequency", "powerflex", "sinamics", "drive")),
    (DeviceClass.BMS_CONTROLLER, ("bms", "bacnet", "building management", "hvac", "niagara", "jace")),
    (DeviceClass.IP_CAMERA, ("camera", "hikvision", "axis", "cctv", "nvr")),
    (DeviceClass.NETWORK_SWITCH, ("switch", "moxa", "stratix", "scalance")),
    (DeviceClass.FIREWALL, ("firewall", "palo alto", "fortigate", "checkpoint")),
    (DeviceClass.ROUTER, ("router", "gateway router")),
    (DeviceClass.IOT_GATEWAY, ("iot gateway", "edge gateway")),
    (DeviceClass.SERVER, ("server", "windows server")),
    (DeviceClass.WORKSTATION, ("workstation", "desktop", "pc")),
    (DeviceClass.PRINTER, ("printer",)),
]


def classify_device(*text: str | None) -> DeviceClass:
    """Best-effort device classification from free-text fields."""
    blob = " ".join(t for t in text if t).lower()
    for dc, keys in _CLASS_KEYWORDS:
        if any(k in blob for k in keys):
            return dc
    return DeviceClass.UNKNOWN


def default_purdue(dc: DeviceClass) -> PurdueLevel:
    return DEFAULT_PURDUE.get(dc, PurdueLevel.UNKNOWN)
