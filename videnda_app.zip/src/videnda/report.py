"""Turn a scored inventory into a summary dict + a plain-text console report.

This is the Sprint 1 'free diagnostic' output in text form; Sprint 2 renders the
same summary as PDF/DOCX with an Azure OpenAI narrative and CAF/NIS2 mapping.
"""
from __future__ import annotations

from collections import Counter

from .models import Inventory
from .risk import top_risks


def build_summary(inv: Inventory) -> dict:
    by_class = Counter(a.device_class.value for a in inv.assets)
    by_purdue = Counter(a.purdue_level.value for a in inv.assets)
    by_band = Counter(a.risk_band for a in inv.assets)
    finding_counts: Counter = Counter()
    for a in inv.assets:
        for f in a.findings:
            finding_counts[f.category] += 1
    return {
        "generated_at": inv.generated_at.isoformat(),
        "source_files": inv.source_files,
        "total_assets": len(inv.assets),
        "assets_with_findings": sum(1 for a in inv.assets if a.findings),
        "by_device_class": dict(by_class.most_common()),
        "by_purdue_level": dict(by_purdue.most_common()),
        "by_risk_band": dict(by_band.most_common()),
        "findings": {
            "known_exploited_vulns": finding_counts.get("KEV", 0),
            "end_of_life": finding_counts.get("EOL", 0),
            "likely_default_creds": finding_counts.get("DEFAULT_CREDS", 0),
            "internet_exposed": finding_counts.get("EXPOSURE", 0),
        },
        "top_risks": [
            {
                "asset_id": a.asset_id,
                "label": a.hostname or a.ip or a.product or a.asset_id,
                "device_class": a.device_class.value,
                "risk_score": a.risk_score,
                "risk_band": a.risk_band,
                "top_finding": (a.findings[0].title if a.findings else None),
            }
            for a in top_risks(inv, 5)
        ],
    }


def render_console(inv: Inventory) -> str:
    s = build_summary(inv)
    L: list[str] = []
    L.append("=" * 64)
    L.append("  Videnda, OT Asset Inventory & Risk Snapshot")
    L.append("=" * 64)
    L.append(f"  Source: {', '.join(s['source_files']) or 'n/a'}")
    L.append(f"  Assets discovered:      {s['total_assets']}")
    L.append(f"  Assets with findings:   {s['assets_with_findings']}")
    L.append("")
    L.append("  Headline risks")
    f = s["findings"]
    L.append(f"    Known-exploited vulns (CISA KEV): {f['known_exploited_vulns']}")
    L.append(f"    End-of-life / unsupported:        {f['end_of_life']}")
    L.append(f"    Likely default credentials:       {f['likely_default_creds']}")
    L.append(f"    Internet-exposed devices:         {f['internet_exposed']}")
    L.append("")
    L.append("  Risk bands: " + ", ".join(f"{k}={v}" for k, v in s["by_risk_band"].items()))
    L.append("")
    L.append("  Fix these first")
    if s["top_risks"]:
        for i, t in enumerate(s["top_risks"], 1):
            L.append(f"    {i}. [{t['risk_band']:8} {t['risk_score']:5}] {t['label']} "
                     f"({t['device_class']}), {t['top_finding']}")
    else:
        L.append("    No risks detected in this sample.")
    L.append("=" * 64)
    return "\n".join(L)
