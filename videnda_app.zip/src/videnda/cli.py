"""Videnda command-line runner.

Usage:
    PYTHONPATH=src python -m videnda.cli run --input samples/sample_assets.csv
    PYTHONPATH=src python -m videnda.cli run --input scan.xml --json out/inventory.json
"""
from __future__ import annotations

import argparse
import json
import sys

from .ingest import ingest
from .enrich import enrich
from .risk import score_inventory
from .report import build_summary, render_console


def _run(args: argparse.Namespace) -> int:
    inv = ingest(args.input, fmt=args.format)
    enrich(inv, live_kev=args.live_kev)
    score_inventory(inv)
    print(render_console(inv))
    if args.json:
        payload = {
            "summary": build_summary(inv),
            "assets": [a.model_dump(mode="json") for a in inv.assets],
        }
        import os
        os.makedirs(os.path.dirname(args.json) or ".", exist_ok=True)
        with open(args.json, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, default=str)
        print(f"\nFull inventory written to {args.json}")
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="videnda", description="Guided OT asset inventory & risk snapshot")
    sub = p.add_subparsers(dest="cmd", required=True)
    run = sub.add_parser("run", help="Ingest a file, enrich, score, and print a snapshot")
    run.add_argument("--input", "-i", required=True, help="CSV/Excel asset list or Nmap XML")
    run.add_argument("--format", "-f", default="auto", choices=["auto", "csv", "nmap"])
    run.add_argument("--json", help="Write full enriched inventory JSON to this path")
    run.add_argument("--live-kev", action="store_true", help="Refresh CISA KEV from the live feed")
    run.set_defaults(func=_run)
    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
