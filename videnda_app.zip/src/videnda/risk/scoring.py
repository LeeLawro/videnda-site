"""Deterministic, explainable risk scoring.

Score is driven by concrete findings, then modulated by how close the asset is
to the physical process (Purdue level) and its business criticality. Everything
is transparent so a non-expert can see *why* a device is ranked where it is.
"""
from __future__ import annotations

from ..models import Asset, Inventory
from ..taxonomy import CRITICALITY_RISK_WEIGHT, PURDUE_RISK_WEIGHT

# base points per finding category
_BASE_POINTS = {
    "KEV": 45.0,
    "EXPOSURE": 30.0,
    "DEFAULT_CREDS": 25.0,
    "EOL": 20.0,
    "CVE": 12.0,
}
_RANSOMWARE_BONUS = 15.0

RISK_BANDS = [(75.0, "Critical"), (50.0, "High"), (25.0, "Medium"), (0.01, "Low")]


def _band(score: float) -> str:
    for threshold, name in RISK_BANDS:
        if score >= threshold:
            return name
    return "None"


def score_asset(asset: Asset) -> Asset:
    base = 0.0
    for f in asset.findings:
        base += _BASE_POINTS.get(f.category, 5.0)
        if f.category == "KEV" and f.evidence.get("ransomware"):
            base += _RANSOMWARE_BONUS
    weight = PURDUE_RISK_WEIGHT.get(asset.purdue_level, 1.0) * CRITICALITY_RISK_WEIGHT.get(asset.criticality, 1.0)
    score = round(min(base * weight, 100.0), 1)
    asset.risk_score = score
    asset.risk_band = _band(score)
    return asset


def score_inventory(inventory: Inventory) -> Inventory:
    for a in inventory.assets:
        score_asset(a)
    return inventory


def top_risks(inventory: Inventory, n: int = 5) -> list[Asset]:
    ranked = sorted(inventory.assets, key=lambda a: a.risk_score, reverse=True)
    return [a for a in ranked if a.risk_score > 0][:n]
