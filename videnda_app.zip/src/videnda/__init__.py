"""Videnda, guided OT asset inventory, enrichment and risk scoring (Sprint 0)."""
__version__ = "0.1.0"
