"""Canonical asset & finding models, the single normalised shape every
ingestion source is mapped into and every enricher reads/writes."""
from __future__ import annotations

import hashlib
from datetime import date, datetime, timezone
from typing import Any, Optional

from pydantic import BaseModel, Field

from .taxonomy import Criticality, DeviceClass, PurdueLevel, default_purdue


class Finding(BaseModel):
    """A single risk observation attached to an asset by an enricher."""
    category: str                      # KEV | EOL | DEFAULT_CREDS | EXPOSURE | CVE
    severity: str                      # critical | high | medium | low | info
    title: str
    description: str
    references: list[str] = Field(default_factory=list)
    evidence: dict[str, Any] = Field(default_factory=dict)
    source: str = ""                   # which enricher / data source produced it


class Asset(BaseModel):
    """Canonical OT/BMS asset record."""
    asset_id: str = ""
    hostname: Optional[str] = None
    ip: Optional[str] = None
    mac: Optional[str] = None
    vendor: Optional[str] = None
    product: Optional[str] = None
    model: Optional[str] = None
    firmware_version: Optional[str] = None
    os: Optional[str] = None
    device_class: DeviceClass = DeviceClass.UNKNOWN
    purdue_level: PurdueLevel = PurdueLevel.UNKNOWN
    criticality: Criticality = Criticality.UNKNOWN
    site: Optional[str] = None
    zone: Optional[str] = None
    protocols: list[str] = Field(default_factory=list)
    open_ports: list[int] = Field(default_factory=list)
    source: str = ""                   # ingestion source (csv | nmap | ...)
    first_seen: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    raw: dict[str, Any] = Field(default_factory=dict)

    # populated by enrichment / scoring
    findings: list[Finding] = Field(default_factory=list)
    risk_score: float = 0.0
    risk_band: str = "None"

    def model_post_init(self, __context: Any) -> None:
        if self.purdue_level == PurdueLevel.UNKNOWN and self.device_class != DeviceClass.UNKNOWN:
            self.purdue_level = default_purdue(self.device_class)
        if not self.asset_id:
            self.asset_id = self._make_id()

    def _make_id(self) -> str:
        key = "|".join(str(x) for x in (self.mac, self.ip, self.hostname, self.product, self.model))
        return "ast_" + hashlib.sha1(key.encode()).hexdigest()[:12]

    # convenience -------------------------------------------------------
    def text_blob(self) -> str:
        return " ".join(
            str(x) for x in (self.vendor, self.product, self.model, self.os, self.firmware_version) if x
        )

    def add_finding(self, f: Finding) -> None:
        self.findings.append(f)


class Inventory(BaseModel):
    """A collection of assets plus provenance metadata."""
    assets: list[Asset] = Field(default_factory=list)
    generated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    source_files: list[str] = Field(default_factory=list)

    def __len__(self) -> int:
        return len(self.assets)
