"""Orchestrates all enrichers over an inventory."""
from __future__ import annotations

import ipaddress
from dataclasses import dataclass

from ..models import Asset, Finding, Inventory
from .kev import enrich_kev, load_kev
from .eol import enrich_eol, load_eol
from .default_creds import enrich_default_creds, load_default_creds


@dataclass
class ReferenceData:
    kev: list[dict]
    eol: list[dict]
    default_creds: list[dict]


def load_reference_data(live_kev: bool = False) -> ReferenceData:
    return ReferenceData(
        kev=load_kev(live=live_kev),
        eol=load_eol(),
        default_creds=load_default_creds(),
    )


def _enrich_exposure(asset: Asset) -> None:
    """Flag assets with a routable public IP, OT should never be internet-facing."""
    if not asset.ip:
        return
    try:
        addr = ipaddress.ip_address(asset.ip)
    except ValueError:
        return
    if addr.is_global:
        asset.add_finding(
            Finding(
                category="EXPOSURE",
                severity="high",
                title="Internet-exposed / public IP address",
                description=(
                    f"Asset has a public IP ({asset.ip}). OT/BMS devices should sit behind "
                    "segmentation and never be directly reachable from the internet."
                ),
                references=["https://www.cisa.gov/news-events/cybersecurity-advisories"],
                evidence={"ip": asset.ip},
                source="exposure-check",
            )
        )


def enrich_asset(asset: Asset, ref: ReferenceData) -> Asset:
    enrich_kev(asset, ref.kev)
    enrich_eol(asset, ref.eol)
    enrich_default_creds(asset, ref.default_creds)
    _enrich_exposure(asset)
    return asset


def enrich(inventory: Inventory, ref: ReferenceData | None = None, live_kev: bool = False) -> Inventory:
    if ref is None:
        ref = load_reference_data(live_kev=live_kev)
    for asset in inventory.assets:
        enrich_asset(asset, ref)
    return inventory
