"""Documented default-credential heuristic.

We cannot (and must not) test credentials. Instead we flag assets whose
make/model is *documented* to ship with default credentials AND that expose a
management service, a conservative, clearly-labelled 'UNVERIFIED' finding for
the operator to confirm on the device.
"""
from __future__ import annotations

from ..models import Asset, Finding
from ..taxonomy import DeviceClass
from ._data import load_json

# management-plane ports whose exposure makes default creds meaningful
_MGMT_PORTS = {21, 22, 23, 80, 443, 502, 4840, 44818, 47808, 8080, 8443, 9000}


def load_default_creds(cred_file: str = "default_creds.json") -> list[dict]:
    return load_json(cred_file).get("entries", [])


def enrich_default_creds(asset: Asset, entries: list[dict]) -> None:
    vendor = (asset.vendor or "").lower()
    dc = asset.device_class.value.lower()
    exposes_mgmt = (not asset.open_ports) or any(p in _MGMT_PORTS for p in asset.open_ports)
    for e in entries:
        ev = (e.get("vendor") or "").lower()
        edc = (e.get("device_class") or "").lower()
        vendor_hit = ev and ev in vendor
        class_hit = edc and edc == dc
        if (vendor_hit or class_hit) and exposes_mgmt:
            cred_hint = e.get("username", "")
            if e.get("password"):
                cred_hint += f" / {e.get('password')}"
            asset.add_finding(
                Finding(
                    category="DEFAULT_CREDS",
                    severity="high",
                    title="Likely default credentials (UNVERIFIED)",
                    description=(
                        f"This {asset.vendor or 'device'} {asset.device_class.value} model is documented to "
                        f"ship with default credentials ({cred_hint or 'vendor default account'}). "
                        "Videnda has NOT tested them, confirm on the device and change if still default."
                    ),
                    references=["https://www.cisa.gov/resources-tools/resources/changing-default-passwords"],
                    evidence={"reference": e.get("reference"), "credential_hint": cred_hint or None},
                    source="default-creds-list",
                )
            )
            return
