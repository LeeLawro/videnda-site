"""CISA Known Exploited Vulnerabilities (KEV) matching.

Flags assets whose vendor/product plausibly matches an entry in the CISA KEV
catalog, vulnerabilities that are *actively exploited in the wild*, i.e. the
single strongest 'fix this now' signal available, and all from public data.
"""
from __future__ import annotations

import os
from typing import Optional

from ..models import Asset, Finding
from ._data import load_json


def _tokens(s: Optional[str]) -> set[str]:
    if not s:
        return set()
    return {t for t in "".join(c.lower() if c.isalnum() else " " for c in s).split() if len(t) > 2}


def load_kev(kev_file: str = "kev_sample.json", live: bool = False) -> list[dict]:
    """Load the KEV catalog. If live=True, try the official feed, else bundled."""
    if live:
        url = os.environ.get("CLEAROT_KEV_URL")
        if url:
            try:  # pragma: no cover - network optional
                import requests
                data = requests.get(url, timeout=15).json()
                return data.get("vulnerabilities", [])
            except Exception:
                pass
    return load_json(kev_file).get("vulnerabilities", [])


def enrich_kev(asset: Asset, catalog: list[dict]) -> None:
    if not asset.vendor and not asset.product and not asset.os:
        return
    vendor_tok = _tokens(asset.vendor)
    prod_tok = _tokens(asset.product) | _tokens(asset.model) | _tokens(asset.os)
    for entry in catalog:
        ev = _tokens(entry.get("vendorProject"))
        ep = _tokens(entry.get("product"))
        vendor_match = bool(vendor_tok & ev) or bool(prod_tok & ev)
        product_match = bool(prod_tok & ep)
        if vendor_match and product_match:
            ransomware = str(entry.get("knownRansomwareCampaignUse", "")).lower() == "known"
            asset.add_finding(
                Finding(
                    category="KEV",
                    severity="critical",
                    title=f"Known-exploited vulnerability: {entry.get('cveID')}",
                    description=(
                        f"{entry.get('vulnerabilityName')}, this CVE is on the CISA KEV "
                        f"catalog (actively exploited in the wild)."
                        + (" Linked to known ransomware campaigns." if ransomware else "")
                    ),
                    references=[
                        f"https://nvd.nist.gov/vuln/detail/{entry.get('cveID')}",
                        "https://www.cisa.gov/known-exploited-vulnerabilities-catalog",
                    ],
                    evidence={
                        "cveID": entry.get("cveID"),
                        "matched_vendor": entry.get("vendorProject"),
                        "matched_product": entry.get("product"),
                        "ransomware": ransomware,
                        "dueDate": entry.get("dueDate"),
                    },
                    source="cisa-kev",
                )
            )
