"""End-of-life / end-of-support detection."""
from __future__ import annotations

from ..models import Asset, Finding
from ._data import load_json


def load_eol(eol_file: str = "eol_sample.json") -> list[dict]:
    return load_json(eol_file).get("products", [])


def enrich_eol(asset: Asset, products: list[dict]) -> None:
    blob = " ".join(x.lower() for x in (asset.vendor or "", asset.product or "",
                                        asset.model or "", asset.os or "",
                                        asset.firmware_version or ""))
    if not blob.strip():
        return
    for p in products:
        vendor = (p.get("vendor") or "").lower()
        product = (p.get("product") or "").lower()
        if product and product in blob and (not vendor or vendor in blob):
            asset.add_finding(
                Finding(
                    category="EOL",
                    severity="high",
                    title=f"End-of-life software/hardware: {p.get('product')}",
                    description=(
                        f"{p.get('product')} reached end of support on {p.get('eol_date')}. "
                        "It no longer receives security patches and should be isolated or replaced."
                    ),
                    references=["https://endoflife.date/"],
                    evidence={"product": p.get("product"), "eol_date": p.get("eol_date")},
                    source="eol-list",
                )
            )
            return
