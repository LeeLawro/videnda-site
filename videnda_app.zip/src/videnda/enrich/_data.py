from __future__ import annotations
import json, os
from functools import lru_cache

_DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "..", "data")


def data_path(name: str) -> str:
    return os.path.normpath(os.path.join(_DATA_DIR, name))


@lru_cache(maxsize=None)
def load_json(name: str) -> dict:
    with open(data_path(name), "r", encoding="utf-8") as fh:
        return json.load(fh)
