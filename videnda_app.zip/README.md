# Videnda, Sprint 0

**Videnda**, Latin for *“the things that must be seen.”* A product of **CyberSafe Coach Plus Ltd**, sharing the house that also runs the Amitura engine behind CyberSafe Coach.


Guided OT/BMS **asset inventory, enrichment and risk scoring** for under-resourced
operators (SME manufacturing first). This is the *moat* layer from the product spec:
it does **not** try to out-detect Claroty/Nozomi/Dragos. It takes asset data you
already have (a spreadsheet or an Nmap scan), normalises it to the **CISA OT asset
taxonomy**, enriches it against **public** vulnerability intelligence, and produces
the outcome a non-expert needs: a clean inventory, a risk snapshot, and a
"fix these first" list.

> Sprint 0 = engine only (schema + ingestion + enrichment + scoring + CLI).
> Sprints 1-3 add the web UI, accounts/history, NIS2/CAF evidence pack, and the
> Defender-for-IoT/Sentinel monitored tier. See `Videnda_Product_Build_Spec.docx`.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt          # just pydantic for Sprint 0
export PYTHONPATH=src

# Run the diagnostic on the bundled samples
python -m videnda.cli run --input samples/sample_assets.csv
python -m videnda.cli run --input samples/sample_nmap.xml --json out/inventory.json
```

Optional extras: `pip install openpyxl` (read `.xlsx`), `pip install requests`
(`--live-kev` refreshes the CISA KEV catalog from the live feed).

## What it does

| Stage | Module | Notes |
|-------|--------|-------|
| Ingest | `videnda.ingest` | CSV/Excel (fuzzy header matching) + Nmap XML → canonical `Asset` |
| Classify | `videnda.taxonomy` | Device class + Purdue level (CISA-aligned) |
| Enrich | `videnda.enrich` | CISA **KEV**, **EOL**/end-of-support, documented **default creds** (UNVERIFIED), internet **exposure** |
| Score | `videnda.risk` | Deterministic, explainable score weighted by Purdue level + criticality |
| Report | `videnda.report` | Summary dict + console snapshot (JSON export for the future UI) |

## Design principles

- **Public data only**, CISA KEV, ICS advisories, NVD, EOL lists. No secret sauce
  to license; the moat is the taxonomy mapping, scoring logic and UX.
- **Never test credentials**, default-cred findings are clearly labelled
  `UNVERIFIED` for the operator to confirm. Safety first in OT.
- **Explainable**, every finding cites its source; every score is reproducible.
- **Offline-capable**, bundled reference data in `data/` so a pilot works with no
  outbound network; `--live-kev` upgrades to the live feed when available.

## Tests

```bash
PYTHONPATH=src python -m pytest -q      # 10 tests
```

## Web app (Sprint 1): the free diagnostic

A FastAPI front-end wraps the engine so a visitor can upload a file and get the
snapshot in a browser. Files are processed in memory and not stored.

```bash
pip install -r requirements.txt fastapi "uvicorn[standard]" python-multipart
export PYTHONPATH=src
python -m uvicorn videnda.web.app:app --reload
# open http://127.0.0.1:8000  (or /scan-sample to try the bundled sample)
```

Routes: `/` upload page, `/scan` (multipart POST) results page, `/scan-sample`
demo with bundled data, `/api/scan` JSON API, `/health` healthcheck.
`samples/sample_snapshot.html` is a static preview of the results view.

Next: containerise and deploy to Azure Container Apps, add accounts/history
(Sprint 2), then the NIS2/CAF evidence pack and the Defender-for-IoT monitored
tier (Sprint 3).

## Layout

```
src/videnda/
  taxonomy.py        CISA-aligned device classes, Purdue levels, classifier
  models.py          Canonical Asset / Finding / Inventory (pydantic)
  ingest/            csv_ingest.py, nmap_ingest.py, format detection
  enrich/            kev.py, eol.py, default_creds.py, pipeline.py (+ exposure)
  risk/scoring.py    Deterministic scoring + top_risks()
  report.py          Summary + console renderer
  cli.py             `videnda run ...`
data/                Bundled sample KEV / EOL / default-cred reference data
samples/             sample_assets.csv, sample_nmap.xml
tests/               pytest suite
```

## Roadmap (next)

1. Expand reference data + wire `--live-kev` and NVD lookups.
2. Sprint 1: FastAPI wrapper + minimal web upload UI (the free diagnostic).
3. Sprint 2: accounts, history/drift, NIS2/CAF evidence pack, Azure OpenAI narrative.
4. Sprint 3: Microsoft Defender for IoT + Sentinel ingestion for the monitored tier.

_Not security advice; findings are automated and should be validated by a competent person._
