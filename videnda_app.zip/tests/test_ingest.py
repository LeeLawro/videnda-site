import os
from videnda.ingest import ingest, detect_format
from videnda.taxonomy import DeviceClass

HERE = os.path.dirname(__file__)
SAMPLES = os.path.join(HERE, "..", "samples")


def test_csv_ingest_maps_fuzzy_headers():
    inv = ingest(os.path.join(SAMPLES, "sample_assets.csv"))
    assert len(inv) == 8
    plc = next(a for a in inv.assets if a.hostname == "LINE1-PLC-01")
    assert plc.vendor == "Siemens"
    assert plc.device_class == DeviceClass.PLC
    # Purdue level auto-derived from device class
    assert plc.purdue_level.value == "L1_BasicControl"


def test_detect_format():
    assert detect_format(os.path.join(SAMPLES, "sample_nmap.xml")) == "nmap"
    assert detect_format(os.path.join(SAMPLES, "sample_assets.csv")) == "csv"


def test_nmap_ingest_skips_down_hosts_and_reads_ports():
    inv = ingest(os.path.join(SAMPLES, "sample_nmap.xml"))
    assert len(inv) == 2  # down host excluded
    plc = next(a for a in inv.assets if a.ip == "10.20.1.11")
    assert 102 in plc.open_ports
    assert plc.vendor == "Siemens"
