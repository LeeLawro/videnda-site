import os
from fastapi.testclient import TestClient
from videnda.web.app import app

client = TestClient(app)
HERE = os.path.dirname(__file__)
SAMPLE = os.path.join(HERE, "..", "samples", "sample_assets.csv")


def test_home_page_loads():
    r = client.get("/")
    assert r.status_code == 200
    assert "Videnda" in r.text
    assert "Run the snapshot" in r.text


def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_scan_sample_html():
    r = client.get("/scan-sample")
    assert r.status_code == 200
    assert "Fix these first" in r.text
    assert "Full inventory" in r.text


def test_api_scan_returns_summary():
    with open(SAMPLE, "rb") as fh:
        data = fh.read()
    r = client.post("/api/scan", files={"file": ("sample_assets.csv", data, "text/csv")})
    assert r.status_code == 200
    payload = r.json()
    assert payload["summary"]["total_assets"] == 8
    assert payload["summary"]["findings"]["known_exploited_vulns"] >= 1
    assert len(payload["assets"]) == 8


def test_scan_html_upload():
    with open(SAMPLE, "rb") as fh:
        data = fh.read()
    r = client.post("/scan", files={"file": ("sample_assets.csv", data, "text/csv")})
    assert r.status_code == 200
    assert "Asset & risk snapshot" in r.text


def test_empty_file_is_handled():
    r = client.post("/api/scan", files={"file": ("empty.csv", b"", "text/csv")})
    assert r.status_code == 400
