import os
from videnda.ingest import ingest
from videnda.enrich import enrich

HERE = os.path.dirname(__file__)
SAMPLES = os.path.join(HERE, "..", "samples")


def _enriched():
    inv = ingest(os.path.join(SAMPLES, "sample_assets.csv"))
    return enrich(inv)


def test_kev_match_on_siemens_plc():
    inv = _enriched()
    plc = next(a for a in inv.assets if a.hostname == "LINE1-PLC-01")
    cats = {f.category for f in plc.findings}
    assert "KEV" in cats


def test_eol_match_on_windows7():
    inv = _enriched()
    ws = next(a for a in inv.assets if a.hostname == "ENG-WS-03")
    assert any(f.category == "EOL" for f in ws.findings)


def test_exposure_flag_on_public_ip():
    inv = _enriched()
    cam = next(a for a in inv.assets if a.hostname == "CAM-DOCK-2")
    assert any(f.category == "EXPOSURE" for f in cam.findings)


def test_default_creds_unverified_label():
    inv = _enriched()
    cam = next(a for a in inv.assets if a.hostname == "CAM-DOCK-2")
    dc = [f for f in cam.findings if f.category == "DEFAULT_CREDS"]
    assert dc and "UNVERIFIED" in dc[0].title
