import os
from videnda.ingest import ingest
from videnda.enrich import enrich
from videnda.risk import score_inventory, top_risks

HERE = os.path.dirname(__file__)
SAMPLES = os.path.join(HERE, "..", "samples")


def _scored():
    inv = ingest(os.path.join(SAMPLES, "sample_assets.csv"))
    enrich(inv)
    return score_inventory(inv)


def test_scores_are_bounded_and_banded():
    inv = _scored()
    for a in inv.assets:
        assert 0.0 <= a.risk_score <= 100.0
        assert a.risk_band in {"None", "Low", "Medium", "High", "Critical"}


def test_top_risks_sorted_desc_and_nonzero():
    inv = _scored()
    tops = top_risks(inv, 5)
    assert tops
    scores = [a.risk_score for a in tops]
    assert scores == sorted(scores, reverse=True)
    assert all(s > 0 for s in scores)


def test_kev_asset_outranks_clean_asset():
    inv = _scored()
    plc = next(a for a in inv.assets if a.hostname == "LINE1-PLC-01")  # KEV
    sw = next(a for a in inv.assets if a.hostname == "SW-CELL2-01")    # likely low
    assert plc.risk_score >= sw.risk_score
