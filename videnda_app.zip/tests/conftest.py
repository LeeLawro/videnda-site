import os, sys
ROOT = os.path.dirname(os.path.dirname(__file__))
sys.path.insert(0, os.path.join(ROOT, "src"))
SAMPLES = os.path.join(ROOT, "samples")
